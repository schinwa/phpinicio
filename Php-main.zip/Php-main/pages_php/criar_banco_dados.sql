CREATE DATABASE meu_banco;
USE meu_banco;
CREATE TABLE minha_tabela (
    id INTEGER AUTO_INCREMENT PRIMARY KEY
    ,campo_01 VARCHAR(50)
    ,campo_02 VARCHAR(50)
    ,campo_03 VARCHAR(50)
    ,campo_04 VARCHAR(50)
    ,campo_05 VARCHAR(50)
    ,campo_06 VARCHAR(50)
    ,campo_07 VARCHAR(50)
    ,campo_08 VARCHAR(50)
    ,campo_09 VARCHAR(50)
    ,campo_10 VARCHAR(50)
);

INSERT INTO minha_tabela ( 
    campo_01 ,campo_02 ,campo_03 ,campo_04 ,campo_05 ,campo_06 ,campo_07 ,campo_08 ,campo_09 ,campo_10 
) VALUES (
     'Valor A - 01'
    ,'Valor A - 02'
    ,'Valor A - 03'
    ,'Valor A - 04'
    ,'Valor A - 05'
    ,'Valor A - 06'
    ,'Valor A - 07'
    ,'Valor A - 08'
    ,'Valor A - 09'
    ,'Valor A - 10'
);
INSERT INTO minha_tabela ( 
    campo_01 ,campo_02 ,campo_03 ,campo_04 ,campo_05 ,campo_06 ,campo_07 ,campo_08 ,campo_09 ,campo_10 
) VALUES (
     'Valor B - 01'
    ,'Valor B - 02'
    ,'Valor B - 03'
    ,'Valor B - 04'
    ,'Valor B - 05'
    ,'Valor B - 06'
    ,'Valor B - 07'
    ,'Valor B - 08'
    ,'Valor B - 09'
    ,'Valor B - 10'
);
INSERT INTO minha_tabela ( 
    campo_01 ,campo_02 ,campo_03 ,campo_04 ,campo_05 ,campo_06 ,campo_07 ,campo_08 ,campo_09 ,campo_10 
) VALUES (
     'Valor C - 01'
    ,'Valor C - 02'
    ,'Valor C - 03'
    ,'Valor C - 04'
    ,'Valor C - 05'
    ,'Valor C - 06'
    ,'Valor C - 07'
    ,'Valor C - 08'
    ,'Valor C - 09'
    ,'Valor C - 10'
);
INSERT INTO minha_tabela ( 
    campo_01 ,campo_02 ,campo_03 ,campo_04 ,campo_05 ,campo_06 ,campo_07 ,campo_08 ,campo_09 ,campo_10 
) VALUES (
     'Valor D - 01'
    ,'Valor D - 02'
    ,'Valor D - 03'
    ,'Valor D - 04'
    ,'Valor D - 05'
    ,'Valor D - 06'
    ,'Valor D - 07'
    ,'Valor D - 08'
    ,'Valor D - 09'
    ,'Valor D - 10'
);
INSERT INTO minha_tabela ( 
    campo_01 ,campo_02 ,campo_03 ,campo_04 ,campo_05 ,campo_06 ,campo_07 ,campo_08 ,campo_09 ,campo_10 
) VALUES (
     'Valor E - 01'
    ,'Valor E - 02'
    ,'Valor E - 03'
    ,'Valor E - 04'
    ,'Valor E - 05'
    ,'Valor E - 06'
    ,'Valor E - 07'
    ,'Valor E - 08'
    ,'Valor E - 09'
    ,'Valor E - 10'
);
